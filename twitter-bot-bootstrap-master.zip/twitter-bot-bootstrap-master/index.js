require('./src/bot')
